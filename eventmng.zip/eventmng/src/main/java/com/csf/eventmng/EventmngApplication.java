package com.csf.eventmng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventmngApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventmngApplication.class, args);
	}

}

